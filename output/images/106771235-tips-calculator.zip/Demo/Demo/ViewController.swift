//
//  ViewController.swift
//  Demo
//
//  Created by makzan on 2018-10-09.
//  Copyright © 2018 makzan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var outputLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        inputTextField.becomeFirstResponder()
    }
    
    func calculateTipsResult(percentages:Float) {
        if inputTextField.text != nil {
            let input = Float(inputTextField.text!)!
            let result = input * (1+percentages/100)
            outputLabel.text = String(format: "$%.2f", result)
        }
        
    }

    @IBAction func tapPercentage(_ sender: Any) {
        calculateTipsResult(percentages: Float((sender as! UIView).tag))
    }

    
}

